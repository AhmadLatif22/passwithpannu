import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

/// Displays the currently published policy and records explicit acceptance.
/// Publish policies/active in Firestore through an admin-only backend.
class TermsPage extends StatefulWidget {
  const TermsPage({super.key, this.requiredAcceptance = false});
  final bool requiredAcceptance;
  @override
  State<TermsPage> createState() => _TermsPageState();
}
class _TermsPageState extends State<TermsPage> {
  bool checked = false, saving = false;
  Future<void> accept(Map<String, dynamic> terms) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;
    setState(() => saving = true);
    try {
      final version = terms['version'] as String;
      final policyText = terms['text'] as String;
      final ref = FirebaseFirestore.instance.collection('users').doc(user.uid).collection('termsAcceptances').doc(version);
      await ref.set({
        'version': version,
        'policyText': policyText, // immutable acceptance snapshot (protect with rules)
        'acceptedAt': FieldValue.serverTimestamp(),
        'uid': user.uid,
      });
      if (mounted) context.go('/home');
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Could not record acceptance: $e')));
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Terms & Conditions'), automaticallyImplyLeading: !widget.requiredAcceptance),
    body: StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance.collection('policies').doc('active').snapshots(),
      builder: (context, snap) {
        if (snap.hasError) return const Center(child: Text('Terms are unavailable. Contact your instructor.'));
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
        final terms = snap.data!.data();
        if (terms == null || terms['version'] is! String || terms['text'] is! String || (terms['text'] as String).trim().isEmpty) {
          return const Center(child: Text('Terms have not been published yet. Contact your instructor.'));
        }
        return ListView(padding: const EdgeInsets.all(20), children: [
          Text('Version ${terms['version']}', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 12), SelectableText(terms['text'] as String),
          if (widget.requiredAcceptance) ...[
            const SizedBox(height: 24),
            CheckboxListTile(value: checked, onChanged: (v) => setState(() => checked = v ?? false), title: const Text('I have read and agree to these Terms & Conditions')),
            FilledButton(onPressed: checked && !saving ? () => accept(terms) : null, child: Text(saving ? 'Recording acceptance…' : 'Accept and continue')),
          ],
        ]);
      },
    ),
  );
}
